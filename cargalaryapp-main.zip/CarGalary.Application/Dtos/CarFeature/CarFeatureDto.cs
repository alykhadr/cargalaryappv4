using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarGalary.Application.Dtos
{
    public class CarFeatureDto
{
    public int Id { get; set; }
    public string NameAr { get; set; } = null!;
}

}