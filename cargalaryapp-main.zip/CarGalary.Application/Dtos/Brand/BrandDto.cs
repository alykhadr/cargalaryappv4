using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarGalary.Application.Dtos.Brand
{
    public class BrandDto
    {
        public string? NameAr { get; set; } 
    public string? NameEn { get; set; } 

    }
}