

namespace CarGalary.Application.Dtos.Branch.Command
{
    public class UpdateBranchWorkingDayRequestDto
    {
        public int Id { get; set; }
        public bool IsAvailable { get; set; }
    }
}