using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarGalary.Application.Dtos
{
    public class CarColorCreateDto
    {
        
    }
}