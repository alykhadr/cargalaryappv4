

using CarGalary.Application.Dtos;

namespace CarGalary.Application.Interfaces
{
   public interface IFavoritesService
{
    // Task AddToFavoritesAsync(int userId, int carId);
    // Task RemoveFromFavoritesAsync(int userId, int carId);
    // Task<List<FavoriteCarDto>> GetMyFavoritesAsync(int userId);
}
}