


using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface IMemberServiceService
{
    // Task<IEnumerable<MemberService>> GetAllAsync();
    // Task<MemberService> GetByIdAsync(int id);
    // Task<MemberService> CreateAsync(MemberService memberService);
    // Task<bool> UpdateAsync(int id, MemberService memberService);
    // Task<bool> DeleteAsync(int id);
}

}