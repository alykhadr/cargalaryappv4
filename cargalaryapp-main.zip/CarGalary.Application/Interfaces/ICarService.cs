
using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface ICarService
    {

        // Task<List<Car>> GetAllAsync();
        // Task<Car?> GetByIdAsync(int id);
        // Task<Car> CreateAsync(Car car);
        // Task<bool> UpdateAsync(int id, Car car);
        // Task<bool> DeleteAsync(int id);
        // Task<bool> CarExistsAsync(int id);
        // Task<List<Car>> FilterAsync(int? brandId = null, int? typeId = null, bool? isAvailable = null);
    }
}