



using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
   public interface IServicesService
{
    // Task<IEnumerable<Services>> GetAllAsync();
    // Task<Services> GetByIdAsync(int id);
    // Task<IEnumerable<Services>> GetByServiceTypeIdAsync(int serviceTypeId);
    // Task<Services> CreateAsync(Services service);
    // Task<bool> UpdateAsync(int id, Services service);
    // Task<bool> DeleteAsync(int id);
}
}