

using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface IOfferService
    {
        //  Task<IEnumerable<Offer>> GetAllAsync();
        // Task<Offer> GetByIdAsync(int id);
        // Task<Offer> CreateAsync(Offer offer);
        // Task<bool> UpdateAsync(Offer offer);
        // Task<bool> DeleteAsync(int id);
    }
}