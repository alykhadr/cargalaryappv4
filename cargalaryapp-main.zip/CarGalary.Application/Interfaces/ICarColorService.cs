using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarGalary.Domain.Entities;


namespace CarGalary.Application.Interfaces
{
    public interface ICarColorService
{
    //  Task<CarColor> AddCarColorAsync(CarColor carColor);
    // Task<CarColor?> GetCarColorByIdAsync(int id);
    // Task<IEnumerable<CarColor>> GetAllCarColorsAsync();
    // Task<bool> UpdateCarColorAsync(CarColor carColor);
    // Task<bool> DeleteCarColorAsync(int id);
}
}