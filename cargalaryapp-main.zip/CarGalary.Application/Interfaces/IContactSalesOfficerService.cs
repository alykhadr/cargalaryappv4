

using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface IContactSalesOfficerService
    {
    //     Task<IEnumerable<ContactSalesOfficer>> GetAllAsync();
    // Task<ContactSalesOfficer> GetByIdAsync(int id);
    // Task<ContactSalesOfficer> CreateAsync(ContactSalesOfficer model);
    // Task<bool> UpdateAsync(int id, ContactSalesOfficer model);
    // Task<bool> DeleteAsync(int id);
    }
}