


using CarGalary.Api.Dtos;
using CarGalary.Application.Dtos;

namespace CarGalary.Application.Interfaces
{
    public interface IUserProfileService
    {
       
        // Task<UserProfileResponseDto?> GetProfileByUserIdAsync(int userId);
        // Task<UserProfileResponseDto> CreateProfileAsync(int userId, CreateUserProfileRequestDto dto, string? createdBy);
        // Task<UserProfileResponseDto?> UpdateProfileAsync(int userId, UpdateUserProfileRequestDto dto);
        // Task<bool> DeleteProfileAsync(int userId);
    }
}