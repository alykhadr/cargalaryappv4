


using CarGalary.Application.Dtos;

namespace CarGalary.Application.Interfaces
{
    public interface ICarFeatureService
    {
        
        // Task<List<CarFeatureDto>> GetAllAsync();
        // Task<CarFeatureDto> CreateAsync(string name);
        // Task AssignFeaturesToCarAsync(int carId, List<int> featureIds);
    }
}