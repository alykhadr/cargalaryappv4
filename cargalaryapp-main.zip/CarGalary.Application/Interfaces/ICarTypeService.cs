

namespace CarGalary.Application.Interfaces
{
    public interface ICarTypeService
    {
        //  Task<List<CarType>> GetCarTypes();
        //   Task<CarType> GetCarTypeById(int id);

        //   Task CreateCarType(CarType type);

        // Task<bool> UpdateCarType(int id,CarType type);
        //  Task<bool>  CarTypeExists(int id);

        // Task<bool> DeleteCarTypeById(int id);
    }
}