

using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface ICompanyInformationService
    {
        
        // Task<IEnumerable<CompanyInformation>> GetAllAsync();
        // Task<CompanyInformation> GetByIdAsync(int id);
        // Task<CompanyInformation> CreateAsync(CompanyInformation company);
        // Task<bool> UpdateAsync(CompanyInformation company);
        // Task<bool> DeleteAsync(int id);
    }
}