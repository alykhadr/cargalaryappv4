


using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface IFAQService
{
    // Task<IEnumerable<FAQ>> GetAllAsync();
    // Task<IEnumerable<FAQ>> GetAvailableAsync();
    // Task<FAQ> GetByIdAsync(int id);
    // Task<FAQ> CreateAsync(FAQ faq);
    // Task<bool> UpdateAsync(int id, FAQ faq);
    // Task<bool> DeleteAsync(int id);
}

}