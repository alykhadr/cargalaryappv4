

namespace CarGalary.Application.Interfaces
{
    public interface IContactUsService
    {
        // Task<IEnumerable<ContactUs>> GetAllAsync();
    }
}