



using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface IServiceTypeService
    {
        // Task<IEnumerable<ServiceType>> GetAllAsync();
        // Task<ServiceType> GetByIdAsync(int id);
        // Task<ServiceType> CreateAsync(ServiceType serviceType);
        // Task<bool> UpdateAsync(int id, ServiceType serviceType);
        // Task<bool> DeleteAsync(int id);
    }
}