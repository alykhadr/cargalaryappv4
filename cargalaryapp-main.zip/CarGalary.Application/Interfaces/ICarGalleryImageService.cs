
using CarGalary.Domain.Entities;

namespace CarGalary.Application.Interfaces
{
    public interface ICarGalleryImageService
    {
        // Task<CarGalleryImage> AddImageAsync(CarGalleryImage image);
        // Task<CarGalleryImage?> GetImageByIdAsync(int imageId);
        // Task<IEnumerable<CarGalleryImage>> GetImagesByCarAsync(int carId);
        // Task<bool> UpdateImageAsync(CarGalleryImage image);
        // Task<bool> DeleteImageAsync(int imageId);
    }
}